package se233.chapter1;

public class JarLauncher {
    public static void main(String[] args) {
        Launcher.main(args);
    }
}
