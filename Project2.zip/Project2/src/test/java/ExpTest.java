import javafx.application.Platform;
import javafx.scene.control.ProgressBar;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import se233.project2.controller.MainController;
import se233.project2.entity.Player;
import se233.project2.entity.enemyShip;
import se233.project2.gameLoop.GameLoop;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ExpTest {
    @BeforeAll
    public static void initToolkit() {
        Platform.startup(() -> {}); // Initialize JavaFX toolkit
    }
    @BeforeEach
    public void PlayerInitialization() {
        Platform.runLater(() -> {
            ProgressBar abilityCooldownBar = new ProgressBar(0);
            abilityCooldownBar.setPrefWidth(50);
            abilityCooldownBar.setPrefHeight(9);
            abilityCooldownBar.setVisible(false);
        });
    }
    @Test
    public void GainExpTest() {
        Player player = new Player(); // initialize as per your setup
        MainController controller = Mockito.mock(MainController.class);
        enemyShip enemy = new enemyShip(0, 0);
        int intialExp = Player.getExp();
        enemy.destroyed();

        assertEquals(intialExp + 4, Player.getExp(), "Player X position after moving right should increase by speed");
    }
}
