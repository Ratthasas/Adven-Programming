import javafx.application.Platform;
import javafx.scene.control.ProgressBar;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import se233.project2.controller.MainController;
import se233.project2.entity.Player;
import se233.project2.gameLoop.GameLoop;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AbilityTest {
    @BeforeAll
    public static void initToolkit() {
        Platform.startup(() -> {}); // Initialize JavaFX toolkit
    }
    @BeforeEach
    public void PlayerInitialization() {
        Platform.runLater(() -> {
            ProgressBar abilityCooldownBar = new ProgressBar(0);
            abilityCooldownBar.setPrefWidth(50);
            abilityCooldownBar.setPrefHeight(9);
            abilityCooldownBar.setVisible(false);
        });
    }
    @Test
    public void ability1Test() {
        Player player = new Player(); // initialize as per your setup
        MainController controller = Mockito.mock(MainController.class);
        GameLoop gameLoop = Mockito.mock(GameLoop.class);

        MainController.selectedIndex = 0;
        double intialInterval = player.getShootInterval();
        Player.activateSpecialAbility();

        assertEquals(intialInterval/2, player.getShootInterval());
    }
}
