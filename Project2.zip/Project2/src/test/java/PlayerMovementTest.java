import javafx.application.Platform;
import javafx.scene.control.ProgressBar;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.Mockito;
import se233.project2.controller.MainController;
import se233.project2.entity.Player;
import se233.project2.gameLoop.GameLoop;

public class PlayerMovementTest {
    @BeforeAll
    public static void initToolkit() {
        Platform.startup(() -> {}); // Initialize JavaFX toolkit
    }
    @BeforeEach
    public void PlayerInitialization() {
        Platform.runLater(() -> {
            ProgressBar abilityCooldownBar = new ProgressBar(0);
            abilityCooldownBar.setPrefWidth(50);
            abilityCooldownBar.setPrefHeight(9);
            abilityCooldownBar.setVisible(false);
        });
    }
    @Test
    public void testPlayerMovesCorrectly() {
        Player player = new Player(); // initialize as per your setup
        MainController controller = Mockito.mock(MainController.class);
        GameLoop gameLoop = Mockito.mock(GameLoop.class);

        // Assuming movement increments position by a specified speed
        double initialX = player.getX();
        double initialY = player.getY();

        player.moveRight(); // or any movement method
        assertEquals(initialX + player.getSpeed(), player.getX(), "Player X position after moving right should increase by speed");

        player.moveUp();
        assertEquals(initialY + player.getSpeed(), player.getY(), "Player X position after moving right should increase by speed");

        // Add tests for all other movement directions or conditions
    }
}