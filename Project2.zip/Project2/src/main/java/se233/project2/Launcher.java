package se233.project2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.input.KeyCombination;
import javafx.stage.Stage;
import se233.project2.util.CustomUncaughtExceptionHandler;

import java.io.IOException;

public class Launcher extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Launcher.class.getResource("main-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Game");
        stage.setScene(scene);
        stage.fullScreenExitHintProperty().setValue("");
        stage.fullScreenExitKeyProperty().setValue(KeyCombination.valueOf("Alt+F4"));
        stage.setFullScreen(true);
        stage.show();
    }

    public static void main(String[] args) {
        Thread.setDefaultUncaughtExceptionHandler(new CustomUncaughtExceptionHandler());
        launch();
    }
}