package se233.project2;

public class JarLauncher {
    public static void main(String[] args) {
        Launcher.main(args);
    }
}