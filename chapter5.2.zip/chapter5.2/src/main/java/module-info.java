module se223.chapter5_2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens se223.chapter5_2 to javafx.fxml;
    exports se223.chapter5_2;
}