package se223.chapter5_2.controller;

import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyCode;
import javafx.geometry.Point2D;
import se223.chapter5_2.model.Direction;
import se223.chapter5_2.model.Food;
import se223.chapter5_2.model.Snake;
import se223.chapter5_2.view.GameStage;

import java.util.Random;

public class GameLoop implements Runnable {
    private GameStage gameStage;
    private Snake snake;
    private Food food;
    private boolean lastFoodWasSpecial = false;
    private float interval = 1000.0f / 10;
    private boolean running;
    private Random random = new Random();

    public GameLoop(GameStage gameStage, Snake snake, Food food) {
        this.snake = snake;
        this.gameStage = gameStage;
        this.food = food;
        running = true;
    }

    private void keyProcess() {
        KeyCode curKey = gameStage.getKey();
        Direction curDirection = snake.getDirection();
        if (curKey == KeyCode.UP && curDirection != Direction.DOWN)
            snake.setDirection(Direction.UP);
        else if (curKey == KeyCode.DOWN && curDirection != Direction.UP)
            snake.setDirection(Direction.DOWN);
        else if (curKey == KeyCode.LEFT && curDirection != Direction.RIGHT)
            snake.setDirection(Direction.LEFT);
        else if (curKey == KeyCode.RIGHT && curDirection != Direction.LEFT)
            snake.setDirection(Direction.RIGHT);
        snake.move();
    }

    private void checkCollision() {
        if (snake.collided(food)) {
            snake.grow();
            snake.increaseScore(food.getPointValue());  // Increase score

            // Decide to generate special food or not
            boolean generateSpecialFood = Math.random() < 0.25 && !lastFoodWasSpecial;  // 25% generate special food

            // Generate new food at random position
            Point2D newFoodPosition = new Point2D(random.nextInt(GameStage.WIDTH), random.nextInt(GameStage.HEIGHT));
            if (generateSpecialFood) {
                food = new Food(newFoodPosition, true);
                lastFoodWasSpecial = true;
            } else {
                food = new Food(newFoodPosition, false);
                lastFoodWasSpecial = false;
            }
        }

        if (snake.checkDead()) {
            running = false;
            Platform.runLater(this::showGameOverPopup);
        }
    }

    private void redraw() {
        gameStage.render(snake, food);
        gameStage.updateScore(snake.getScore());  // Update the score
    }

    private void showGameOverPopup() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Game Over");
        alert.setHeaderText(null);
        alert.setContentText("Game Over! The snake has died.");
        alert.showAndWait();
    }

    @Override
    public void run() {
        while (running) {
            keyProcess();
            checkCollision();
            redraw();
            try {
                Thread.sleep((long) interval);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
