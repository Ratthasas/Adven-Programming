package se223.chapter5_2.model;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import se223.chapter5_2.view.GameStage;

import java.util.Random;

public class Food {
    private Point2D position;
    private Random rn;
    private int pointValue;
    private Color color;

    // Constructor for regular food
    public Food(Point2D position) {
        this.rn = new Random();
        this.position = position;
        this.pointValue = 1;  // Default point value for regular food
        this.color = Color.RED;  // Default color for regular food
    }

    // Constructor for special food
    public Food(Point2D position, boolean isSpecial) {
        this.rn = new Random();
        this.position = position;
        if (isSpecial) {
            this.pointValue = 5;  // Point value for special food
            this.color = Color.GREEN;  // Color for special food
        } else {
            this.pointValue = 1;  // Default point value
            this.color = Color.RED;  // Default color
        }
    }

    public void respawn() {
        Point2D prevPosition = this.position;
        do {
            this.position = new Point2D(rn.nextInt(GameStage.WIDTH), rn.nextInt(GameStage.HEIGHT));
        } while (prevPosition.equals(this.position));
    }

    public Point2D getPosition() {
        return position;
    }

    public int getPointValue() {
        return pointValue;
    }

    public Color getColor() {
        return color;
    }
}
