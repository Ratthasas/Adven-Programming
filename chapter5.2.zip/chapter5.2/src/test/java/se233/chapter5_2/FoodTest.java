package se233.chapter5_2;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import se223.chapter5_2.model.Food;

import static org.junit.jupiter.api.Assertions.*;

public class FoodTest {
    private Food specialFood;
    private Food regularFood;

    @BeforeEach
    public void setup() {
        specialFood = new Food(new Point2D(5, 5), true); // Special food with 5 points
        regularFood = new Food(new Point2D(1, 1), false); // Regular food with 1 point
    }

    @Test
    public void specialFood_shouldHaveFivePoints() {
        assertEquals(5, specialFood.getPointValue());
    }

    @Test
    public void regularFood_shouldHaveOnePoint() {
        assertEquals(1, regularFood.getPointValue());
    }

    @Test
    public void specialFood_shouldBeGreen() {
        assertEquals(Color.GREEN, specialFood.getColor());
    }

    @Test
    public void regularFood_shouldBeRed() {
        assertEquals(Color.RED, regularFood.getColor());
    }

    @Test
    public void respawn_shouldBeOnNewPosition() {
        Food food = new Food(new Point2D(0, 0));
        Point2D originalPosition = food.getPosition();
        food.respawn();
        assertNotEquals(originalPosition, food.getPosition(), "Food should respawn at a new location.");
    }

    @Test
    public void specialFoodCreation() {
        Food specialFood = new Food(new Point2D(10, 10), true);
        assertEquals(5, specialFood.getPointValue());
        assertEquals(Color.GREEN, specialFood.getColor());
    }
}
