package se223.project1.model;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.*;
import javafx.scene.input.MouseButton;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import se223.project1.function.EdgeDetector;
import se223.project1.utils.ContextMenuBehavior;
import static se223.project1.controller.MainController.currentContextMenu;
import static se223.project1.function.Cropping.cropMode;
import static se223.project1.function.Cropping.takeSnapshot;

public class ViewportManager {
    public static HBox viewport;
    public static Rectangle cropBox = new Rectangle();
    private static Pane cornerPane = new Pane();
    private static boolean maintainAspectRatio = false;
    public static void setViewport(HBox viewport) {
        ViewportManager.viewport = viewport;
    }

    public static void setMaintainAspectRatio(boolean maintainAspectRatio) {
        ViewportManager.maintainAspectRatio = maintainAspectRatio;
    }

    public static void setCropBoxVisible() {
        Platform.runLater(() -> {
            if(cropMode){
                cropBox.setVisible(true);
                cornerPane.setVisible(true);
            } else {
                cropBox.setVisible(false);
                cornerPane.setVisible(false);
            }
        });
    }

    public static void updateViewport(Image image) {
        setupViewport(image, true);
        setupViewport(image, false);
        setCropBoxVisible();
    }

    public static boolean hasImageInViewport() {
        return viewport.getChildren().size() > 1;
    }

    public static void setupViewport(Image image, boolean clearViewport) {
        Platform.runLater(() -> {
            if (clearViewport) {
                viewport.getChildren().clear();
            } else if (viewport.getChildren().size() > 1) {
                viewport.getChildren().remove(1);
            }

            ImageView imageView = new ImageView(image);
            imageView.setPreserveRatio(true);
            imageView.setFitWidth((viewport.getWidth() / 2) - 20);
            imageView.setFitHeight((viewport.getHeight() / 2) - 20);
            double imageAspectRatio = image.getWidth() / image.getHeight();

            StackPane stackPane = new StackPane();
            stackPane.getChildren().add(imageView);
            stackPane.setStyle("-fx-background-color: gray;");
            if(clearViewport) {
                stackPane.getChildren().add(createCropBoxWithCornerPanes(imageView, imageAspectRatio));
            }

            ScrollPane scrollPane = createScrollPane(stackPane);
            scrollPane.setPrefSize(viewport.getWidth() / 2, viewport.getHeight());
            setupScrollPaneContextMenu(scrollPane, imageView);

            scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
            scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

            viewport.getChildren().add(scrollPane);

            setupZooming(imageView);
            setupDragging(imageView);
        });
    }


    private static ScrollPane createScrollPane(Node container) {
        ScrollPane scrollPane = new ScrollPane(container);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        scrollPane.setPannable(false);
        scrollPane.setStyle("-fx-alignment: center;");
        return scrollPane;
    }

    private static StackPane createCropBoxWithCornerPanes(ImageView imageView, double imageAspectRatio) {
        getCropBox(imageView, imageAspectRatio);

        cornerPane = createCornerPane(cropBox);

        StackPane.setAlignment(cornerPane, Pos.BOTTOM_RIGHT);

        StackPane container = new StackPane();
        container.setMaxWidth(0);
        container.setMaxHeight(0);
        container.setPickOnBounds(false);
        container.getChildren().addAll(cropBox, cornerPane);

        return container;
    }

    private static void getCropBox(ImageView imageView, double imageAspectRatio) {
        double fitWidth = imageView.getFitWidth();
        double fitHeight = imageView.getFitHeight();
        double displayedWidth, displayedHeight;
        if (fitWidth / fitHeight < imageAspectRatio) {
            displayedWidth = fitWidth;
            displayedHeight = fitWidth / imageAspectRatio;
        } else {
            displayedHeight = fitHeight;
            displayedWidth = fitHeight * imageAspectRatio;
        }
        cropBox.setFill(Color.TRANSPARENT);
        cropBox.setStroke(Color.BLACK);
        cropBox.setStrokeWidth(1.5);
        cropBox.setMouseTransparent(true);
        cropBox.setWidth(displayedWidth);
        cropBox.setHeight(displayedHeight);
    }

    private static Pane createCornerPane(Rectangle borderRectangle) {
        double size = Math.min(borderRectangle.getWidth(), borderRectangle.getHeight()) / 10;

        Pane cornerPane = new Pane();
        cornerPane.setMinSize(20, 20);
        cornerPane.setMaxSize(size, size);
        cornerPane.setStyle("-fx-background-color: transparent; -fx-border-color: lightgrey; -fx-border-width: 1.5;");

        final double[] initialWidth = {borderRectangle.getWidth()};
        final double[] initialHeight = {borderRectangle.getHeight()};
        final double[] initialX = {0};
        final double[] initialY = {0};

        cornerPane.setOnMousePressed(event -> {
            initialX[0] = event.getSceneX();
            initialY[0] = event.getSceneY();
            initialWidth[0] = borderRectangle.getWidth();
            initialHeight[0] = borderRectangle.getHeight();
            event.consume();
        });

        cornerPane.setOnMouseDragged(event -> {
            double deltaX = event.getSceneX() - initialX[0];
            double deltaY = event.getSceneY() - initialY[0];

            double newWidth = Math.max(0, initialWidth[0] + deltaX);
            double newHeight = Math.max(0, initialHeight[0] + deltaY);

            if (maintainAspectRatio) {
                double aspectRatio = initialWidth[0] / initialHeight[0];

                if (newWidth / newHeight > aspectRatio) {
                    newWidth = newHeight * aspectRatio;
                } else {
                    newHeight = newWidth / aspectRatio;
                }
            }

            double maxWidth = (viewport.getWidth() / 2) - 20;
            if (newWidth > maxWidth) {
                newWidth = maxWidth;
                if (maintainAspectRatio) {
                    newHeight = newWidth / (initialWidth[0] / initialHeight[0]);
                }
            }

            double maxHeight = viewport.getHeight() - 25;
            if (newHeight > maxHeight) {
                newHeight = maxHeight;
                if (maintainAspectRatio) {
                    newWidth = newHeight * (initialWidth[0] / initialHeight[0]);
                }
            }

            borderRectangle.setWidth(newWidth);
            borderRectangle.setHeight(newHeight);

            event.consume();
        });

        cornerPane.setOnMouseEntered(event -> cornerPane.setStyle("-fx-background-color: rgba(211, 211, 211, 0.1); -fx-border-color: lightgrey; -fx-border-width: 1.5;"));

        cornerPane.setOnMouseExited(event -> cornerPane.setStyle("-fx-background-color: transparent; -fx-border-color: lightgrey; -fx-border-width: 1.5;"));

        return cornerPane;
    }

    private static void setupZooming(ImageView imageView) {
        final double zoomFactor = 1.1;
        imageView.getParent().addEventFilter(ScrollEvent.SCROLL, event -> {
            double deltaY = event.getDeltaY();
            double scale = deltaY > 0 ? zoomFactor : 1 / zoomFactor;
            imageView.setScaleX(imageView.getScaleX() * scale);
            imageView.setScaleY(imageView.getScaleY() * scale);
            imageView.setScaleX(Math.max(0.1, Math.min(imageView.getScaleX(), 10)));
            imageView.setScaleY(Math.max(0.1, Math.min(imageView.getScaleY(), 10)));

            event.consume();
        });
    }

    private static void setupDragging(ImageView imageView) {
        final double[] dragAnchorX = {0};
        final double[] dragAnchorY = {0};

        imageView.setOnMousePressed(event -> {
            if (event.getButton() == MouseButton.SECONDARY) {
                showContextMenu(event, imageView);
            } else if (event.getTarget() == imageView) {
                dragAnchorX[0] = event.getSceneX();
                dragAnchorY[0] = event.getSceneY();
            }
        });

        imageView.setOnMouseDragged(event -> {
            if (event.getButton() == MouseButton.PRIMARY && event.getTarget() == imageView) {
                double offsetX = event.getSceneX() - dragAnchorX[0];
                double offsetY = event.getSceneY() - dragAnchorY[0];
                imageView.setTranslateX(imageView.getTranslateX() + offsetX);
                imageView.setTranslateY(imageView.getTranslateY() + offsetY);
                dragAnchorX[0] = event.getSceneX();
                dragAnchorY[0] = event.getSceneY();
            }
        });
    }


    private static void showContextMenu(javafx.scene.input.MouseEvent event, ImageView imageView) {
        ContextMenu contextMenu = new ContextMenu();
        ContextMenuBehavior.setupContextMenuBehavior();
        if (currentContextMenu != null && currentContextMenu.isShowing()) {
            currentContextMenu.hide();
        }

        MenuItem resetItem = new MenuItem("Reset Image Location");
        resetItem.setOnAction(e -> {
            imageView.setTranslateX(0);
            imageView.setTranslateY(0);
            imageView.setScaleX(1);
            imageView.setScaleY(1);
        });

        MenuItem preview = new MenuItem("Preview Image");
        preview.setOnAction(e -> {
            if(!cropMode){
                Platform.runLater(EdgeDetector::applyEdgeDetection);
            } else{
                setupViewport(takeSnapshot(), false);
            }
        });

        currentContextMenu = contextMenu;
        contextMenu.getItems().addAll(resetItem, preview);
        contextMenu.show(imageView.getParent(), event.getScreenX(), event.getScreenY());
    }


    private static void setupScrollPaneContextMenu(ScrollPane scrollPane, ImageView imageView) {
        scrollPane.setOnMousePressed(event -> {
            if (event.isSecondaryButtonDown()) {
                showContextMenu(event, imageView);
            }
        });
    }

    public static Image getCurrentImage() {
        if (viewport.getChildren().isEmpty()) {
            return null;
        }
        ScrollPane scrollPane = (ScrollPane) viewport.getChildren().getFirst();
        StackPane stackPane = (StackPane) scrollPane.getContent();
        ImageView imageView = (ImageView) stackPane.getChildren().getFirst();
        return imageView.getImage();
    }
}