package se223.project1.model;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import se223.project1.function.AddFileWindow;
import se223.project1.utils.ContextMenuBehavior;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;

import static se223.project1.controller.MainController.currentContextMenu;
import static se223.project1.controller.MainController.executorService;
import static se223.project1.function.Cropping.*;
import static se223.project1.function.ShowPopup.showResetConfirmationDialog;
import static se223.project1.model.ViewportManager.setupViewport;
import static se223.project1.model.ViewportManager.viewport;
import static se223.project1.function.ShowPopup.showError;

public class GalleryManager {
    private static final double minSize = 100;
    private static final double maxSize = 1000;
    public static Pane lastSelectedPane = null;
    public static List<Pane> selectedPanes = new CopyOnWriteArrayList<>();
    private static VBox dropVBox;
    public static void setDropVBox(VBox vbox) {
        dropVBox = vbox;
    }


    public static void displayImage(ExecutorService executorService, File file, TilePane imageTile) {
        executorService.submit(() -> {
            try (FileInputStream fis = new FileInputStream(file)) {
                Image image = new Image(fis);
                Platform.runLater(() -> {
                    ImageView imageView = new ImageView(image);
                    imageView.setPreserveRatio(true);
                    Pane pane = new StackPane(imageView);
                    Tooltip tooltip = new Tooltip(file.getName());
                    Tooltip.install(pane, tooltip);
                    pane.setOnMouseClicked(event -> handleImageSelection(event, pane));
                    pane.setOnContextMenuRequested(event -> showPaneContextMenu(event, pane));
                    imageTile.getChildren().add(pane);
                    resizeImages(imageTile, imageTile.getWidth());
                    if (imageTile.getChildren().size() == 1) {
                        selectImage(pane);
                    }
                });
            } catch (IOException e) {
                Platform.runLater(() -> showError("Failed to load image: " + e.getMessage()));
            }
        });
    }

    private static void resizeImages(TilePane imageTile, double paneWidth) {
        int columns = imageTile.getPrefColumns();
        double availableWidth = paneWidth - ((columns - 1) * imageTile.getHgap()) - imageTile.getPadding().getLeft() - imageTile.getPadding().getRight();
        double imageSize = Math.min(Math.max(availableWidth / columns * 2.11, minSize), maxSize);
        imageTile.getChildren().forEach(node -> {
            if (node instanceof Pane pane) {
                ImageView imageView = (ImageView) pane.getChildren().getFirst();
                imageView.setFitWidth(imageSize);
                imageView.setFitHeight(imageSize);
                pane.setPrefSize(imageSize, imageSize);
            }
        });
    }

    private static void handleImageSelection(MouseEvent event, Pane pane) {
        if (event.getButton() == MouseButton.PRIMARY) {
            if (event.isControlDown() && !processing.get()) {
                if (selectedPanes.contains(pane)) {
                    deselectImage(pane);
                } else {
                    selectImage(pane);
                }
            } else {
                Platform.runLater(() -> {
                    if(!pane.equals(lastSelectedPane) ) {
                        if(selectedPanes.contains(pane)){
                            selectImage(pane);
                        } else{
                            if(processing.get()){
                                showResetConfirmationDialog();
                            } else{
                                selectImage(pane);
                                selectedPanes.forEach(GalleryManager::deselectImage);
                            }
                        }
                    }
                });
            }
        }
    }

    private static void showPaneContextMenu(ContextMenuEvent event, Pane pane) {
        ContextMenu contextMenu = new ContextMenu();
        if (currentContextMenu != null && currentContextMenu.isShowing()) {
            currentContextMenu.hide();
        }

        MenuItem addFile = new MenuItem("Add File");
        addFile.setOnAction(e -> AddFileWindow.handleAddFile(pane, executorService, (TilePane) pane.getParent()));

        MenuItem remove = new MenuItem("Remove");
        remove.setOnAction(e -> {
            if (pane != null) {
                TilePane parent = (TilePane) pane.getParent();
                parent.getChildren().remove(pane);
                selectedPanes.remove(pane);
                croppedImages.remove(pane);
                if(croppedImages.isEmpty()){
                    processing.set(false);
                }
                checkTilePane(parent, pane);
            }
        });

        MenuItem removeSelected = new MenuItem("Remove Selected");
        removeSelected.setOnAction(e -> {
            TilePane parent = (TilePane) pane.getParent();
            selectedPanes.forEach(parent.getChildren()::remove);
            selectedPanes.clear();
            croppedImages.clear();
            processing.set(false);

            checkTilePane(parent, pane);
        });

        MenuItem removeAll = new MenuItem("Remove All");
        removeAll.setOnAction(e -> {
            TilePane parent = (TilePane) pane.getParent();
            parent.getChildren().clear();
            selectedPanes.clear();
            lastSelectedPane = null;
            Platform.runLater(() -> {
                viewport.getChildren().clear();
                viewport.getChildren().add(dropVBox);
            });
        });
        createResetProcessContextMenu(contextMenu);
        currentContextMenu = contextMenu;
        contextMenu.getItems().addAll(addFile, remove, removeSelected, removeAll);
        contextMenu.show(pane, event.getScreenX(), event.getScreenY());
    }

    public static void showTilePaneContextMenu(ContextMenuEvent event, TilePane tilePane) {
        ContextMenu contextMenu = new ContextMenu();
        ContextMenuBehavior.setupContextMenuBehavior();
        if (currentContextMenu != null && currentContextMenu.isShowing()) {
            currentContextMenu.hide();
        }

        MenuItem addFile = new MenuItem("Add File");
        addFile.setOnAction(e -> AddFileWindow.handleAddFile(tilePane, executorService, tilePane));

        createResetProcessContextMenu(contextMenu);

        currentContextMenu = contextMenu;
        contextMenu.getItems().addAll(addFile);
        contextMenu.show(tilePane, event.getScreenX(), event.getScreenY());
    }

    private static void checkTilePane(TilePane parent, Pane pane) {
        if (pane != null && pane.getBorder() != null && !pane.getBorder().getStrokes().isEmpty()) {
            BorderStroke currentBorderStroke = pane.getBorder().getStrokes().getFirst();
            Color currentBorderColor = (Color) currentBorderStroke.getBottomStroke();
            if (!parent.getChildren().isEmpty() && currentBorderColor.equals(Color.DARKSLATEBLUE)) {
                Pane firstPane = (Pane) parent.getChildren().getFirst();
                selectImage(firstPane);
            } else {
                Platform.runLater(() -> {
                    lastSelectedPane = null;
                    viewport.getChildren().clear();
                    viewport.getChildren().add(dropVBox);
                });
            }
        } else {
            if (!parent.getChildren().isEmpty()) {
                Pane firstPane = (Pane) parent.getChildren().getFirst();
                selectImage(firstPane);
            }
        }
    }


    private static void setSelectImage(Pane pane) {
        Platform.runLater(() -> {
            if (!selectedPanes.contains(pane) || processing.get()) {
                if (lastSelectedPane != null && lastSelectedPane != pane) {
                    lastSelectedPane.setBorder(new Border(new BorderStroke(
                            Color.LIGHTBLUE, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(2)
                    )));
                }
                pane.setBorder(new Border(new BorderStroke(
                        Color.DARKSLATEBLUE, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(2)
                )));
                if (!hasLightGreenBackground(pane)) {
                    pane.setBackground(new Background(new BackgroundFill(Color.ALICEBLUE, CornerRadii.EMPTY, Insets.EMPTY)));
                }
                if (!selectedPanes.contains(pane)) {
                    selectedPanes.add(pane);
                }
                if (pane.getChildren() != null && !pane.getChildren().isEmpty()) {
                    ImageView imageView = (ImageView) pane.getChildren().getFirst();
                    ViewportManager.updateViewport(imageView.getImage());
                }

                if (croppedImages.containsKey(pane)) {
                    setupViewport(croppedImages.get(pane), false);
                }

                lastSelectedPane = pane;
            } else {
                selectImage(pane);
                selectedPanes.forEach(GalleryManager::deselectImage);
            }
        });
    }

    public static void selectImage(Pane pane){
        try{
            setSelectImage(pane);
        } catch (NullPointerException | ClassCastException e){
            showError("An error occurred: " + e.getMessage());
        }

    }

    public static void deselectImage(Pane pane) {
        Platform.runLater(() -> {
            BorderStroke currentBorderStroke = null;
            if (pane.getBorder() != null && !pane.getBorder().getStrokes().isEmpty()) {
                currentBorderStroke = pane.getBorder().getStrokes().getFirst();
            }
            if (currentBorderStroke != null) {
                Color currentBorderColor = (Color) currentBorderStroke.getBottomStroke();
                if (currentBorderColor != null && !currentBorderColor.equals(Color.DARKSLATEBLUE)) {
                    pane.setBorder(null);
                    pane.setBackground(Background.EMPTY);
                    selectedPanes.remove(pane);
                }
            }
        });
    }

    public static boolean hasLightGreenBackground(Pane pane) {
        if (pane.getBackground() != null && pane.getBackground().getFills() != null) {
            for (BackgroundFill fill : pane.getBackground().getFills()) {
                if (fill.getFill() instanceof Color) {
                    Color color = (Color) fill.getFill();
                    if (color.equals(Color.LIGHTGREEN)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}