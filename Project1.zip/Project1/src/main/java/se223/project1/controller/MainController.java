package se223.project1.controller;

import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import se223.project1.function.EdgeDetector;
import se223.project1.model.GalleryManager;
import se223.project1.model.ViewportManager;
import se223.project1.function.AddFileWindow;
import se223.project1.function.ShowPopup;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static se223.project1.function.Cropping.*;
import static se223.project1.function.SaveProcessedFile.processMultipleCroppedImages;
import static se223.project1.function.ShowPopup.showError;
import static se223.project1.model.GalleryManager.*;
import static se223.project1.function.SaveProcessedFile.processSelectedImages;
import static se223.project1.model.ViewportManager.cropBox;
import static se223.project1.utils.UISetup.*;
import static se223.project1.utils.UISetup.show;

public class MainController {
    @FXML
    private Button Process_Button;
    @FXML
    private Button Crop_Button;
    @FXML
    private Button Edge_Button;
    @FXML
    private TilePane Image_Tile;
    @FXML
    private Button chooseFile_Button;
    @FXML
    private VBox drop_VBox;
    @FXML
    private HBox center_HBox;
    @FXML
    private ChoiceBox<String> algorithmChoiceBox;
    @FXML
    private ChoiceBox<String> kernelSizeChoiceBox;
    @FXML
    private ChoiceBox<String> gaussianBlurChoiceBox;
    @FXML
    private ChoiceBox<Integer> thresholdChoiceBox;
    @FXML
    private ChoiceBox<String> colorChannelChoiceBox;
    @FXML
    private GridPane MainLayout;
    @FXML
    private VBox kernelSize_VBox;
    @FXML
    private VBox algorithm_VBox;
    @FXML
    private VBox gaussianBlur_VBox;
    @FXML
    private VBox threshold_VBox;
    @FXML
    private VBox colorChannel_VBox;
    @FXML
    private CheckBox invertMagnitude_CheckBox;
    @FXML
    private CheckBox maintainRatio_CheckBox;
    public static ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    public static ContextMenu currentContextMenu;

    @FXML
    public void initialize() {
        GalleryManager.setDropVBox(drop_VBox);
        setupUI(executorService, Crop_Button, Edge_Button, Process_Button, Image_Tile, drop_VBox, center_HBox, algorithmChoiceBox,
                kernelSizeChoiceBox, gaussianBlurChoiceBox, thresholdChoiceBox,
                colorChannelChoiceBox, kernelSize_VBox, algorithm_VBox, gaussianBlur_VBox, threshold_VBox, colorChannel_VBox, invertMagnitude_CheckBox);

        Edge_Button.setOnMouseClicked(event -> edgeMode());

        Crop_Button.setOnMouseClicked(event -> cropMode());

        Process_Button.setOnMouseClicked(event -> {
            try {
                checkEmptyViewport();

                if (!cropMode) {
                    EdgeDetector.applyEdgeDetection();
                    processSelectedImages(event, MainLayout);
                } else {
                    try{
                        takeSnapshot();
                    } catch (RuntimeException e){
                        throw new CroppingException("Error occurred while taking snapshot.", e);
                    }
                    if (selectedPanes.size() == 1 && !processing.get()) {
                        processSelectedImages(event, MainLayout);
                    } else {
                        if (!processing.get()) {
                            processing.set(true);
                        }
                        croppedImages.put(lastSelectedPane, takeSnapshot());
                        lastSelectedPane.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                        if (selectedPanes.size() == croppedImages.size()) {
                            processMultipleCroppedImages(event);
                            return;
                        }
                        for (Pane pane : selectedPanes) {
                            if (!hasLightGreenBackground(pane)) {
                                selectImage(pane);
                                break;
                            }
                        }
                    }
                }
            } catch (EmptyViewportException e) {
                ShowPopup.showError(e.getMessage());
            }
        });

        algorithmChoiceBox.setOnAction(event -> algorithmSetting());

        kernelSizeChoiceBox.setOnAction(event -> EdgeDetector.setKernelSize(kernelSizeChoiceBox.getValue()));
        gaussianBlurChoiceBox.setOnAction(event -> EdgeDetector.setGaussianBlur(gaussianBlurChoiceBox.getValue()));
        thresholdChoiceBox.setOnAction(event -> EdgeDetector.setThreshold(thresholdChoiceBox.getValue()));
        colorChannelChoiceBox.setOnAction(event -> EdgeDetector.setColor(colorChannelChoiceBox.getValue()));
        invertMagnitude_CheckBox.setOnAction(event -> EdgeDetector.setInvertedMagnitude(invertMagnitude_CheckBox.isSelected()));
        maintainRatio_CheckBox.setOnAction(event -> ViewportManager.setMaintainAspectRatio(maintainRatio_CheckBox.isSelected()));

        chooseFile_Button.setOnMouseClicked(event -> AddFileWindow.handleAddFile(chooseFile_Button, MainController.executorService, Image_Tile));
    }

    private void edgeMode(){
        Crop_Button.setTextFill(Color.GRAY);
        Edge_Button.setTextFill(Color.BLUE);
        Edge_Button.setDisable(true);
        Crop_Button.setDisable(false);
        cropMode = false;
        ViewportManager.setCropBoxVisible();
        show(algorithm_VBox);
        show(invertMagnitude_CheckBox);
        hide(maintainRatio_CheckBox);
        algorithmSetting();
        resetProcess();
    }

    private void algorithmSetting(){
        switch (algorithmChoiceBox.getValue()){
            case "Laplacian":
                basicSetting();
                EdgeDetector.setDetector(EdgeDetector.EdgeDetectionAlgorithm.LAPLACIAN);
                break;
            case "Sobel":
                basicSetting();
                EdgeDetector.setDetector(EdgeDetector.EdgeDetectionAlgorithm.SOBEL);
               break;
            case "Prewitt":
                basicSetting();
                EdgeDetector.setDetector(EdgeDetector.EdgeDetectionAlgorithm.PREWITT);
                break;
            case "Robert Cross":
                EdgeDetector.setDetector(EdgeDetector.EdgeDetectionAlgorithm.ROBERT_CROSS);
                robertSetting();
                break;
        }
    }

    private void cropMode(){
        Crop_Button.setTextFill(Color.BLUE);
        Edge_Button.setTextFill(Color.GRAY);
        Edge_Button.setDisable(false);
        Crop_Button.setDisable(true);
        cropMode = true;
        ViewportManager.setCropBoxVisible();
        hide(algorithm_VBox);
        hide(kernelSize_VBox);
        hide(gaussianBlur_VBox);
        hide(threshold_VBox);
        hide(colorChannel_VBox);
        hide(invertMagnitude_CheckBox);
        show(maintainRatio_CheckBox);
    }

    private void basicSetting(){
        show(kernelSize_VBox);
        show(gaussianBlur_VBox);
        show(threshold_VBox);
        hide(colorChannel_VBox);
    }

    private void robertSetting(){
        hide(kernelSize_VBox);
        show(gaussianBlur_VBox);
        show(threshold_VBox);
        show(colorChannel_VBox);
    }

    private void checkEmptyViewport() {
        if (!ViewportManager.hasImageInViewport()) {
            throw new EmptyViewportException();
        }
    }

    public static class EmptyViewportException extends RuntimeException {
        public EmptyViewportException() {
            super("No image in viewport to process.");
        }
    }
}