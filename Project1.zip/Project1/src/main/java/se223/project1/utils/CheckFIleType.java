package se223.project1.utils;

import java.io.File;
import java.util.Arrays;
import java.util.List;

public class CheckFIleType {
    private static final List<String> SUPPORTED_EXTENSIONS = Arrays.asList(".jpg", ".jpeg", ".png");

    public static boolean isSupportedImage(File file) {
        String fileName = file.getName().toLowerCase();
        return SUPPORTED_EXTENSIONS.stream().anyMatch(fileName::endsWith);
    }
}
