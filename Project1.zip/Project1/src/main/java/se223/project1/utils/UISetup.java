package se223.project1.utils;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import se223.project1.function.DragDropHandler;
import se223.project1.function.EdgeDetector;
import se223.project1.model.GalleryManager;
import se223.project1.model.ViewportManager;

import java.util.concurrent.ExecutorService;

public class UISetup {
    public static void setupUI(ExecutorService executorService, Button cropButton, Button edgeButton, Button processButton, TilePane imageTile,
                               VBox dropVBox, HBox centerHBox, ChoiceBox<String> algorithmChoiceBox, ChoiceBox<String> kernelSizeChoiceBox,
                               ChoiceBox<String> gaussianChoiceBox, ChoiceBox<Integer> threadholdChoiceBox, ChoiceBox<String> colorChannelChoiceBox,
                               VBox kernelSizeVBox, VBox algorithmVBox, VBox gaussianBlurVBox, VBox thresholdVBox, VBox colorChannelVBox, CheckBox invertMagnitudeCheckBox) {

        DragDropHandler.setupDragAndDrop(imageTile, imageTile, executorService);
        DragDropHandler.setupDragAndDrop(dropVBox, imageTile, executorService);
        DragDropHandler.setupDragAndDrop(centerHBox, imageTile, executorService);

        ViewportManager.setViewport(centerHBox);
        Style.applyButtonStyles(cropButton, edgeButton, processButton);
        Style.applyTilePaneStyles(imageTile);
        cropButton.setDisable(true);

        algorithmChoiceBox.getItems().addAll("Laplacian", "Sobel", "Prewitt", "Robert Cross");
        algorithmChoiceBox.setValue("Laplacian");
        kernelSizeChoiceBox.getItems().addAll("3x3", "5x5", "7x7");
        kernelSizeChoiceBox.setValue("3x3");
        gaussianChoiceBox.getItems().addAll("No Gaussian Blur", "3x3 Gaussian Blur", "5x5 Gaussian Blur", "7x7 Gaussian Blur");
        gaussianChoiceBox.setValue("No Gaussian Blur");
        threadholdChoiceBox.getItems().addAll(0, 25, 50,75 , 100, 125, 150, 175, 200);
        threadholdChoiceBox.setValue(0);
        colorChannelChoiceBox.getItems().addAll("Red", "Blue", "Green");
        colorChannelChoiceBox.setValue("Red");
        invertMagnitudeCheckBox.setSelected(false);

        EdgeDetector.setGaussianBlur(gaussianChoiceBox.getValue());
        EdgeDetector.setKernelSize(kernelSizeChoiceBox.getValue());
        EdgeDetector.setThreshold(threadholdChoiceBox.getValue());
        EdgeDetector.setColor(colorChannelChoiceBox.getValue());

        hide(invertMagnitudeCheckBox);
        hide(kernelSizeVBox);
        hide(algorithmVBox);
        hide(gaussianBlurVBox);
        hide(thresholdVBox);
        hide(colorChannelVBox);

        imageTile.setOnContextMenuRequested(event -> {
            if (event.getTarget() instanceof TilePane) {
                GalleryManager.showTilePaneContextMenu(event, imageTile);
            }
        });
    }

    public static void hide(Node node) {
        Platform.runLater(() -> {
            node.setVisible(false);
            node.setManaged(false);
        });
    }

    public static void show(Node node) {
        Platform.runLater(() -> {
            node.setVisible(true);
            node.setManaged(true);
        });
    }
}
