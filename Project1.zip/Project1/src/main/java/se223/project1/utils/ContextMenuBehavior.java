package se223.project1.utils;

import javafx.scene.input.MouseEvent;

import static se223.project1.controller.MainController.currentContextMenu;
import static se223.project1.model.ViewportManager.viewport;

public class ContextMenuBehavior {
    public static void setupContextMenuBehavior() {
        viewport.getScene().addEventFilter(MouseEvent.MOUSE_PRESSED, event -> {
            if (currentContextMenu != null && currentContextMenu.isShowing()) {
                currentContextMenu.hide();
            }
        });
    }
}
