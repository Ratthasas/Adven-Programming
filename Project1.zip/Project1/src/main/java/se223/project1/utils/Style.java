package se223.project1.utils;

import javafx.scene.control.Button;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;

public class Style {
    public static void applyButtonStyles(Button cropButton, Button edgeButton, Button processButton) {
        cropButton.setTextFill(Color.BLUE);
        edgeButton.setTextFill(Color.GRAY);

        Background whiteBackground = new Background(new BackgroundFill(Color.WHITE, null, null));
        processButton.setBackground(whiteBackground);
        cropButton.setBackground(whiteBackground);
        edgeButton.setBackground(whiteBackground);

        processButton.setStyle(
                "-fx-border-color: lightgrey; " +
                        "-fx-border-width: 5px; " +
                        "-fx-border-radius: 20px;" +
                        "-fx-background-radius: 20px;" +
                        "-fx-background-insets: 1px"
        );
    }
    public static void applyTilePaneStyles(TilePane imageTile) {
        imageTile.setStyle("-fx-background-color: lightgray;");
    }
}
