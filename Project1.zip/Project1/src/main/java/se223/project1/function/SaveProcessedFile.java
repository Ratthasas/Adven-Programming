package se223.project1.function;

import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.FileChooser;
import javafx.stage.Window;
import javafx.util.Duration;
import se223.project1.controller.MainController;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static se223.project1.controller.MainController.executorService;
import static se223.project1.function.Cropping.cropMode;
import static se223.project1.function.Cropping.takeSnapshot;
import static se223.project1.function.Cropping.croppedImages;
import static se223.project1.model.GalleryManager.selectImage;
import static se223.project1.model.GalleryManager.selectedPanes;
import static se223.project1.function.ShowPopup.showError;
import static se223.project1.model.ViewportManager.*;

public class SaveProcessedFile {
    public static void processSelectedImages(MouseEvent event, Pane mainPane) {
        if (selectedPanes.isEmpty()) {
            showError("No images selected for processing.");
            return;
        }

        CountDownLatch latch = new CountDownLatch(selectedPanes.size());
        List<File> processedImages = new ArrayList<>();
        boolean isSingleImage = selectedPanes.size() == 1;


        ProgressIndicator progressIndicator = new ProgressIndicator(0);
        progressIndicator.setVisible(true);
        mainPane.getChildren().add(progressIndicator);

        for (Pane pane : selectedPanes) {
            Platform.runLater(() -> showProcessingOverlay(pane));

            executorService.submit(() -> {
                try {
                    ImageView imageView = (ImageView) pane.getChildren().getFirst();
                    Image image = imageView.getImage();
                    WritableImage processedImage = null;

                    if (cropMode) {
                        processedImage = takeSnapshot();
                        setupViewport(processedImage, false);
                    } else {
                        processedImage = EdgeDetector.detectEdges(image);
                    }

                    if (isSingleImage) {
                        saveSingleImage(processedImage);
                    } else {
                        File processedImageFile = saveProcessedImage(processedImage);
                        synchronized (processedImages) {
                            processedImages.add(processedImageFile);
                        }
                    }

                    Platform.runLater(() -> hideProcessingOverlay(pane));
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    latch.countDown();
                    Platform.runLater(() -> updateProgressIndicator(progressIndicator, latch, selectedPanes.size()));
                }
            });
        }

        executorService.submit(() -> {
            try {
                latch.await();
                Platform.runLater(() -> {
                    progressIndicator.setVisible(false);
                    if (!isSingleImage) {
                        promptForZipAndSave(processedImages, event);
                    }
                });
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }

    private static void showProcessingOverlay(Pane pane) {
        StackPane overlayPane = new StackPane();
        overlayPane.setStyle("-fx-background-color: rgba(0, 0, 0, 0.5);");
        overlayPane.setPrefSize(pane.getWidth(), pane.getHeight());

        ImageView loadingSpinner = new ImageView(new Image(MainController.class.getResource("/hourglass.png").toExternalForm())); // Replace with your spinner image path
        loadingSpinner.setFitWidth(50);
        loadingSpinner.setFitHeight(50);

        overlayPane.getChildren().add(loadingSpinner);
        StackPane.setAlignment(loadingSpinner, Pos.CENTER);

        RotateTransition rotateTransition = new RotateTransition(Duration.seconds(1), loadingSpinner);
        rotateTransition.setByAngle(360);
        rotateTransition.setCycleCount(Animation.INDEFINITE);
        rotateTransition.play();

        Platform.runLater(() -> pane.getChildren().add(overlayPane));
    }

    private static void hideProcessingOverlay(Pane pane) {
        Platform.runLater(() -> {
            pane.getChildren().removeIf(node -> node instanceof StackPane && node.getStyle().contains("rgba(0, 0, 0, 0.5)"));
        });
    }

    private static void updateProgressIndicator(ProgressIndicator progressIndicator, CountDownLatch latch, int totalImages) {
        double progress = 1.0 - (double) latch.getCount() / totalImages;
        progressIndicator.setProgress(progress);
    }


    public static void processMultipleCroppedImages(MouseEvent event) {
        if (croppedImages.isEmpty()) {
            showError("No cropped images to save.");
            return;
        }

        CountDownLatch latch = new CountDownLatch(croppedImages.size());
        List<File> processedImages = new ArrayList<>();

        for (Map.Entry<Pane, WritableImage> entry : croppedImages.entrySet()) {
            WritableImage croppedImage = entry.getValue();

            executorService.submit(() -> {
                try {
                    File processedImageFile = saveProcessedImage(croppedImage);
                    synchronized (processedImages) {
                        processedImages.add(processedImageFile);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    latch.countDown();
                }
            });
        }

        executorService.submit(() -> {
            try {
                latch.await();
                Platform.runLater(() -> promptForZipAndSave(processedImages, event));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }

    private static File saveProcessedImage(WritableImage processedImage) throws IOException {
        File tempFile = File.createTempFile("processed", ".png");
        ImageIO.write(SwingFXUtils.fromFXImage(processedImage, null), "png", tempFile);
        return tempFile;
    }

    private static void promptForZipAndSave(List<File> processedImages, MouseEvent event) {
        Platform.runLater(() -> {
            ChoiceDialog<String> formatDialog = new ChoiceDialog<>("png", "png", "jpg");
            formatDialog.setTitle("Select Image Format for Zip");
            formatDialog.setHeaderText("Choose the output image format for all images in the zip:");
            formatDialog.setContentText("Format:");

            Optional<String> selectedFormatOpt = formatDialog.showAndWait();

            if (selectedFormatOpt.isEmpty()) {
                return;
            }

            String selectedFormat = selectedFormatOpt.get();

            Window window = ((Node) event.getSource()).getScene().getWindow();

            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save Processed Images as Zip");
            FileChooser.ExtensionFilter zipFilter = new FileChooser.ExtensionFilter("Zip files (*.zip)", "*.zip");
            fileChooser.getExtensionFilters().add(zipFilter);
            fileChooser.setInitialFileName("processed-images.zip");
            File zipFile = fileChooser.showSaveDialog(window);

            if (zipFile != null) {
                try {
                    createZipFile(processedImages, zipFile, selectedFormat);
                } catch (IOException e) {
                    e.printStackTrace();
                    showError("Failed to save images as zip.");
                }
            }
        });
    }


    private static void createZipFile(List<File> files, File zipFile, String selectedFormat) throws IOException {
        try (ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(zipFile))) {
            for (File file : files) {
                BufferedImage bufferedImage = ImageIO.read(file);

                File tempFile = File.createTempFile("processed", "." + selectedFormat);
                ImageIO.write(bufferedImage, selectedFormat, tempFile);

                try (FileInputStream fis = new FileInputStream(tempFile)) {
                    ZipEntry zipEntry = new ZipEntry(tempFile.getName());
                    zipOut.putNextEntry(zipEntry);
                    byte[] bytes = new byte[1024];
                    int length;
                    while ((length = fis.read(bytes)) >= 0) {
                        zipOut.write(bytes, 0, length);
                    }
                }

                tempFile.deleteOnExit();
            }
        }
    }

    private static void saveSingleImage(WritableImage image) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Processed Image");
        fileChooser.setInitialFileName("processed-image");

        Platform.runLater(() -> {
            ChoiceDialog<String> formatDialog = new ChoiceDialog<>("png", "png", "jpg");
            formatDialog.setTitle("Select Image Format");
            formatDialog.setHeaderText("Choose the output image format:");
            formatDialog.setContentText("Format:");

            Optional<String> selectedFormatOpt = formatDialog.showAndWait();

            if (selectedFormatOpt.isEmpty()) {
                return;
            }

            String selectedFormat = selectedFormatOpt.get();

            if ("png".equalsIgnoreCase(selectedFormat)) {
                fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG files (*.png)", "*.png"));
            } else if ("jpg".equalsIgnoreCase(selectedFormat)) {
                fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.jpg"));
            }

            File file = fileChooser.showSaveDialog(viewport.getScene().getWindow());
            if (file != null) {
                try {
                    BufferedImage bufferedImage = SwingFXUtils.fromFXImage(image, null);
                    ImageIO.write(bufferedImage, selectedFormat, file);
                } catch (IOException ex) {
                    ex.printStackTrace();
                    showError("Failed to save the image.");
                }
            }
        });
    }
}
