package se223.project1.function;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.layout.TilePane;
import javafx.stage.FileChooser;
import se223.project1.utils.CheckFIleType;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import static se223.project1.function.DragDropHandler.extractAndDisplayZip;
import static se223.project1.model.GalleryManager.displayImage;
import static se223.project1.function.ShowPopup.showError;

public class AddFileWindow {
    public static void handleAddFile(Node node, ExecutorService executorService, TilePane tilePane) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
        FileChooser.ExtensionFilter imageFilter = new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png", "*.zip");
        fileChooser.getExtensionFilters().add(imageFilter);

        try {
            List<File> selectedFiles = fileChooser.showOpenMultipleDialog(node.getScene().getWindow());
            if (selectedFiles != null) {
                for (File file : selectedFiles) {
                    if (CheckFIleType.isSupportedImage(file)) {
                        executorService.submit(() -> {
                            try {
                                displayImage(executorService, file, tilePane);
                            } catch (RuntimeException ex) {
                                showError("Error processing image file: " + file.getName());
                            }
                        });
                    } else if (file.getName().endsWith(".zip")) {
                        executorService.submit(() -> {
                            try {
                                extractAndDisplayZip(executorService, file, tilePane);
                            } catch (IOException ex) {
                                Platform.runLater(() -> showError("Error extracting ZIP file: " + ex.getMessage()));
                            } catch (RuntimeException ex) {
                                showError("Error processing ZIP file: " + file.getName());
                            }
                        });
                    }
                }
            }
        } catch (SecurityException ex) {
            showError("Access to file system denied: " + ex.getMessage());
        }
    }
}
