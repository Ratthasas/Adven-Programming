package se223.project1.function;

import javafx.application.Platform;
import javafx.scene.image.Image;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static se223.project1.model.ViewportManager.getCurrentImage;
import static se223.project1.model.ViewportManager.setupViewport;

public class EdgeDetector {
    private static EdgeDetectionAlgorithm detector;
    private static String kernelSize, gaussianBlur, color;
    private static int threshold;

    public static void setInvertedMagnitude(boolean invertedMagnitude) {
        EdgeDetector.invertedMagnitude = invertedMagnitude;
    }

    private static boolean invertedMagnitude;

    public static EdgeDetectionAlgorithm getDetector() {
        return detector;
    }

    public static void setDetector(EdgeDetectionAlgorithm detector) {
        EdgeDetector.detector = detector;
    }

    public static void setKernelSize(String kernelSize) {
        EdgeDetector.kernelSize = kernelSize;
    }

    public static void setGaussianBlur(String gaussianBlur) {
        EdgeDetector.gaussianBlur = gaussianBlur;
    }

    public static void setColor(String color) {
        EdgeDetector.color = color;
    }

    public static void setThreshold(int threshold) {
        EdgeDetector.threshold = threshold;
    }

    public enum EdgeDetectionAlgorithm {
        SOBEL, LAPLACIAN, PREWITT, ROBERT_CROSS
    }

    public static WritableImage detectEdges(Image inputImage) {
        int width = (int) inputImage.getWidth();
        int height = (int) inputImage.getHeight();
        WritableImage outputImage = new WritableImage(width, height);
        PixelWriter pixelWriter = outputImage.getPixelWriter();

        switch (EdgeDetector.getDetector()) {
            case SOBEL:
                applySobel(inputImage, pixelWriter, width, height);
                break;
            case LAPLACIAN:
                applyLaplacian(inputImage, pixelWriter, width, height);
                break;
            case PREWITT:
                applyPrewitt(inputImage, pixelWriter, width, height);
                break;
            case ROBERT_CROSS:
                applyRoberts(inputImage, pixelWriter, width, height);
                break;
            default:
                throw new IllegalArgumentException("Unsupported edge detection algorithm");
        }
        return outputImage;
    }

    private static void applySobel(Image inputImage, PixelWriter pixelWriter, int width, int height) {
        int[][] gx;
        int[][] gy;
        int kernelOffset;

        switch (kernelSize) {
            case "5x5":
                gx = new int[][]{
                        {-2, -1, 0, 1, 2},
                        {-4, -3, 0, 3, 4},
                        {-6, -5, 0, 5, 6},
                        {-4, -3, 0, 3, 4},
                        {-2, -1, 0, 1, 2}
                };
                gy = new int[][]{
                        {2, 4, 6, 4, 2},
                        {1, 3, 5, 3, 1},
                        {0, 0, 0, 0, 0},
                        {-1, -3, -5, -3, -1},
                        {-2, -4, -6, -4, -2}
                };
                kernelOffset = 2;
                break;
            case "7x7":
                gx = new int[][]{
                        {-3, -2, -1, 0, 1, 2, 3},
                        {-6, -5, -4, 0, 4, 5, 6},
                        {-9, -8, -7, 0, 7, 8, 9},
                        {-12, -11, -10, 0, 10, 11, 12},
                        {-9, -8, -7, 0, 7, 8, 9},
                        {-6, -5, -4, 0, 4, 5, 6},
                        {-3, -2, -1, 0, 1, 2, 3}
                };
                gy = new int[][]{
                        {3, 6, 9, 12, 9, 6, 3},
                        {2, 5, 8, 11, 8, 5, 2},
                        {1, 4, 7, 10, 7, 4, 1},
                        {0, 0, 0, 0, 0, 0, 0},
                        {-1, -4, -7, -10, -7, -4, -1},
                        {-2, -5, -8, -11, -8, -5, -2},
                        {-3, -6, -9, -12, -9, -6, -3}
                };
                kernelOffset = 3;
                break;
            case "3x3":
            default:
                gx = new int[][]{
                        {-1, 0, 1},
                        {-2, 0, 2},
                        {-1, 0, 1}
                };
                gy = new int[][]{
                        {1, 2, 1},
                        {0, 0, 0},
                        {-1, -2, -1}
                };
                kernelOffset = 1;
                break;
        }

        if (!gaussianBlur.equals("No Gaussian Blur")) {
            inputImage = applyGaussianBlur(inputImage, width, height, gaussianBlur);
        }

        int numThreads = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        int[][] magnitudes = new int[width][height];

        for (int t = 0; t < numThreads; t++) {
            final int threadID = t;
            Image finalInputImage = inputImage;
            executor.submit(() -> {
                int chunkSize = height / numThreads;
                int startY = threadID * chunkSize;
                int endY = (threadID == numThreads - 1) ? height - kernelOffset : startY + chunkSize;

                for (int y = Math.max(startY, kernelOffset); y < Math.min(endY, height - kernelOffset); y++) {
                    for (int x = kernelOffset; x < width - kernelOffset; x++) {
                        int gradientX = 0;
                        int gradientY = 0;

                        for (int i = -kernelOffset; i <= kernelOffset; i++) {
                            for (int j = -kernelOffset; j <= kernelOffset; j++) {
                                int rgb = finalInputImage.getPixelReader().getArgb(x + j, y + i); // Use inputImage directly
                                int gray = (int) (0.3 * ((rgb >> 16) & 0xff) + 0.59 * ((rgb >> 8) & 0xff) + 0.11 * (rgb & 0xff));

                                gradientX += gx[i + kernelOffset][j + kernelOffset] * gray;
                                gradientY += gy[i + kernelOffset][j + kernelOffset] * gray;
                            }
                        }

                        int magnitude = (int) Math.sqrt(gradientX * gradientX + gradientY * gradientY);
                        magnitudes[x][y] = magnitude;
                    }
                }
            });
        }

        executor.shutdown();
        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        int maxMagnitude = 0;
        for (int y = kernelOffset; y < height - kernelOffset; y++) {
            for (int x = kernelOffset; x < width - kernelOffset; x++) {
                if (magnitudes[x][y] > maxMagnitude) {
                    maxMagnitude = magnitudes[x][y];
                }
            }
        }

        for (int y = kernelOffset; y < height - kernelOffset; y++) {
            for (int x = kernelOffset; x < width - kernelOffset; x++) {
                int magnitude = magnitudes[x][y];

                magnitude = (int) (((double) magnitude / maxMagnitude) * 255);

                if (magnitude < threshold) {
                    magnitude = 0;
                }

                if(!invertedMagnitude){
                    magnitude = 255 - magnitude;
                }

                pixelWriter.setArgb(x, y, (255 << 24) | (magnitude << 16) | (magnitude << 8) | magnitude);
            }
        }
    }
    private static void applyPrewitt(Image inputImage, PixelWriter pixelWriter, int width, int height) {
        int[][] gx = new int[0][];
        int[][] gy = new int[0][];
        int kernelOffset = 1;


        switch (kernelSize) {
            case "3x3":
                gx = new int[][] {
                        {-1, 0, 1},
                        {-1, 0, 1},
                        {-1, 0, 1}
                };
                gy = new int[][] {
                        {1, 1, 1},
                        {0, 0, 0},
                        {-1, -1, -1}
                };
                break;
            case "5x5":
                gx = new int[][] {
                        {-2, -1, 0, 1, 2},
                        {-2, -1, 0, 1, 2},
                        {-2, -1, 0, 1, 2},
                        {-2, -1, 0, 1, 2},
                        {-2, -1, 0, 1, 2}
                };
                gy = new int[][] {
                        { 2,  2,  2,  2,  2},
                        { 1,  1,  1,  1,  1},
                        { 0,  0,  0,  0,  0},
                        {-1, -1, -1, -1, -1},
                        {-2, -2, -2, -2, -2}
                };
                kernelOffset = 2;
                break;
            case "7x7":
                gx = new int[][] {
                        {-1, -1, -1,  0,  1,  1,  1},
                        {-1, -1, -1,  0,  1,  1,  1},
                        {-1, -1, -1,  0,  1,  1,  1},
                        { 0,  0,  0,  0,  0,  0,  0},
                        { 1,  1,  1,  0, -1, -1, -1},
                        { 1,  1,  1,  0, -1, -1, -1},
                        { 1,  1,  1,  0, -1, -1, -1}
                };
                gy = new int[][] {
                        { 1,  1,  1,  1,  1,  1,  1},
                        { 1,  1,  1,  1,  1,  1,  1},
                        { 1,  1,  1,  1,  1,  1,  1},
                        { 0,  0,  0,  0,  0,  0,  0},
                        {-1, -1, -1, -1, -1, -1, -1},
                        {-1, -1, -1, -1, -1, -1, -1},
                        {-1, -1, -1, -1, -1, -1, -1}
                };
                kernelOffset = 3;
                break;
        }

        if (!gaussianBlur.equals("No Gaussian Blur")) {
            inputImage = applyGaussianBlur(inputImage, width, height, gaussianBlur);
        }

        int numThreads = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        for (int t = 0; t < numThreads; t++) {
            final int threadIndex = t;
            Image finalInputImage = inputImage;
            int[][] finalGx = gx;
            int[][] finalGy = gy;
            int finalKernelOffset = kernelOffset;
            executor.submit(() -> {
                for (int y = finalKernelOffset + threadIndex; y < height - finalKernelOffset; y += numThreads) {
                    for (int x = finalKernelOffset; x < width - finalKernelOffset; x++) {
                        int gradientX = 0;
                        int gradientY = 0;


                        for (int i = -finalKernelOffset; i <= finalKernelOffset; i++) {
                            for (int j = -finalKernelOffset; j <= finalKernelOffset; j++) {
                                int rgb = finalInputImage.getPixelReader().getArgb(x + j, y + i);
                                int gray = (int)((0.299 * ((rgb >> 16) & 0xff)) + (0.587 * ((rgb >> 8) & 0xff)) + (0.114 * (rgb & 0xff)));

                                gradientX += finalGx[i + finalKernelOffset][j + finalKernelOffset] * gray;
                                gradientY += finalGy[i + finalKernelOffset][j + finalKernelOffset] * gray;
                            }
                        }



                        int magnitude = (int) Math.sqrt(gradientX * gradientX + gradientY * gradientY);
                        if (kernelSize.equals("7x7")) {
                            magnitude = Math.min(255, Math.abs(magnitude / 80));
                        } else if (kernelSize.equals("5x5")) {
                            magnitude = Math.min(255, Math.abs(magnitude / 40));
                        } else {
                            magnitude = Math.min(255, Math.abs(magnitude / 4));
                        }

                        if (magnitude < threshold) {
                            magnitude = 0;
                        }

                        if(!invertedMagnitude){
                            magnitude = 255 - magnitude;
                        }

                        pixelWriter.setArgb(x, y, (255 << 24) | (magnitude << 16) | (magnitude << 8) | magnitude);
                    }
                }
            });
        }

        executor.shutdown();
        while (!executor.isTerminated()) {
            // Wait for all tasks to finish
        }
    }

    private static void applyLaplacian(Image inputImage, PixelWriter pixelWriter, int width, int height) {
        if (!gaussianBlur.equals("No Gaussian Blur")) {
            inputImage = applyGaussianBlur(inputImage, width, height, gaussianBlur);
        }

        double[][] kernel = null;
        int kernelOffset = 1;

        double[][] kernel3x3 = {
                {0, -1, 0},
                {-1, 4, -1},
                {0, -1, 0}
        };


        double[][] kernel5x5 = {
                {0, 0, -1, 0, 0},
                {0, -1, -2, -1, 0},
                {-1, -2, 16, -2, -1},
                {0, -1, -2, -1, 0},
                {0, 0, -1, 0, 0}
        };

        double[][] kernel7x7 = {
                {0, 0, -1, -1, -1, 0, 0},
                {0, -1, -3, -3, -3, -1, 0},
                {-1, -3, 0, 7, 0, -3, -1},
                {-1, -3, 7, 24, 7, -3, -1},
                {-1, -3, 0, 7, 0, -3, -1},
                {0, -1, -3, -3, -3, -1, 0},
                {0, 0, -1, -1, -1, 0, 0}
        };

        switch (kernelSize) {
            case "3x3":
                kernel = kernel3x3;
                break;
            case "5x5":
                kernel = kernel5x5;
                kernelOffset = 2;
                break;
            case "7x7":
                kernel = kernel7x7;
                kernelOffset = 3;
                break;
            default:
                throw new IllegalArgumentException("Unsupported kernel size: " + kernelSize);
        }


        int numThreads = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        for (int t = 0; t < numThreads; t++) {
            final int threadIndex = t;
            Image finalInputImage = inputImage;
            double[][] finalKernel = kernel;
            int finalKernelOffset = kernelOffset;
            executor.submit(() -> {
                for (int y = finalKernelOffset + threadIndex; y < height - finalKernelOffset; y += numThreads) {
                    for (int x = finalKernelOffset; x < width - finalKernelOffset; x++) {
                        double sum = 0;

                        for (int i = -finalKernelOffset; i <= finalKernelOffset; i++) {
                            for (int j = -finalKernelOffset; j <= finalKernelOffset; j++) {
                                int rgb = finalInputImage.getPixelReader().getArgb(x + j, y + i);
                                int gray = getGrayscale(rgb);

                                sum += finalKernel[i + finalKernelOffset][j + finalKernelOffset] * gray;
                            }
                        }

                        int normal = kernelSize.equals("5x5") ? 8 : kernelSize.equals("7x7") ? 24 : 1;
                        int magnitude = (int) Math.min(255, Math.max(0, Math.abs(sum) / normal));

                        if (magnitude < threshold) {
                            magnitude = 0;
                        }

                        if(!invertedMagnitude){
                            magnitude = 255 - magnitude;
                        }

                        pixelWriter.setArgb(x, y, (255 << 24) | (magnitude << 16) | (magnitude << 8) | magnitude);
                    }
                }
            });
        }

        executor.shutdown();
        while (!executor.isTerminated()) {
            // Wait for all tasks to finish
        }
    }


        private static void applyRoberts(Image inputImage, PixelWriter pixelWriter, int width, int height) {
        int[][] gx = {
                {1, 0},
                {0, -1}
        };

        int[][] gy = {
                {0, 1},
                {-1, 0}
        };

        if (!gaussianBlur.equals("No Gaussian Blur")) {
            inputImage = applyGaussianBlur(inputImage, width, height, gaussianBlur);
        }

        int numThreads = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        for (int t = 0; t < numThreads; t++) {
            final int threadIndex = t;
            Image finalInputImage = inputImage;
            executor.submit(() -> {
                for (int y = threadIndex; y < height - 1; y += numThreads) {
                    for (int x = 0; x < width - 1; x++) {
                        int gradientX = 0;
                        int gradientY = 0;

                        int rgb = finalInputImage.getPixelReader().getArgb(x, y);
                        int gray1 = getGrayscale(rgb);
                        gradientX += gx[0][0] * gray1;

                        rgb = finalInputImage.getPixelReader().getArgb(x + 1, y + 1);
                        int gray2 = getGrayscale(rgb);
                        gradientX += gx[1][1] * gray2;

                        rgb = finalInputImage.getPixelReader().getArgb(x + 1, y);
                        int gray3 = getGrayscale(rgb);
                        gradientY += gy[0][1] * gray3;

                        rgb = finalInputImage.getPixelReader().getArgb(x, y + 1);
                        int gray4 = getGrayscale(rgb);
                        gradientY += gy[1][0] * gray4;

                        int magnitude = (int) Math.sqrt(gradientX * gradientX + gradientY * gradientY);

                        if (magnitude < threshold) {
                            magnitude = 0;
                        } else {
                            magnitude = 255;
                        }

                        if (invertedMagnitude) {
                            magnitude = 255 - magnitude;
                        }

                        int red = 0, green = 0, blue = 0;
                        switch (color.toLowerCase()) {
                            case "red":
                                red = magnitude;
                                break;
                            case "green":
                                green = magnitude;
                                break;
                            case "blue":
                                blue = magnitude;
                                break;
                            case "grayscale":
                            default:
                                red = green = blue = magnitude;
                                break;
                        }

                        pixelWriter.setArgb(x, y, (255 << 24) | (red << 16) | (green << 8) | blue);
                    }
                }
            });
        }

        executor.shutdown();
        while (!executor.isTerminated()) {
            // Wait for all tasks to finish
        }
    }

    private static int getGrayscale(int rgb) {
        int red = (rgb >> 16) & 0xff;
        int green = (rgb >> 8) & 0xff;
        int blue = rgb & 0xff;

        return Math.min(255, Math.max(0, (int) (0.299 * red + 0.587 * green + 0.114 * blue)));
    }

    private static WritableImage applyGaussianBlur(Image inputImage, int width, int height, String gaussianBlur) {
        double[][] gaussianKernel;
        double kernelSum;

        switch (gaussianBlur) {
            case "3x3 Gaussian Blur":
                gaussianKernel = new double[][]{
                        {1, 2, 1},
                        {2, 4, 2},
                        {1, 2, 1}
                };
                kernelSum = 16.0;
                break;
            case "5x5 Gaussian Blur":
                gaussianKernel = new double[][]{
                        {1, 4, 7, 4, 1},
                        {4, 16, 26, 16, 4},
                        {7, 26, 41, 26, 7},
                        {4, 16, 26, 16, 4},
                        {1, 4, 7, 4, 1}
                };
                kernelSum = 273.0;
                break;
            case "7x7 Gaussian Blur":
                gaussianKernel = new double[][]{
                        {0,  0,  1,  2,  1,  0,  0},
                        {0,  3,  13, 22, 13,  3,  0},
                        {1, 13, 59, 97, 59, 13,  1},
                        {2, 22, 97, 159, 97, 22,  2},
                        {1, 13, 59, 97, 59, 13,  1},
                        {0,  3, 13, 22, 13,  3,  0},
                        {0,  0,  1,  2,  1,  0,  0}
                };
                kernelSum = 1003.0;
                break;
            default:
                throw new IllegalArgumentException("Unsupported Gaussian blur type");
        }

        int kernelWidth = gaussianKernel.length;
        int kernelHeight = gaussianKernel[0].length;

        WritableImage blurredImage = new WritableImage(width, height);
        PixelWriter blurWriter = blurredImage.getPixelWriter();

        int kernelRadiusX = kernelWidth / 2;
        int kernelRadiusY = kernelHeight / 2;

        for (int x = kernelRadiusX; x < width - kernelRadiusX; x++) {
            for (int y = kernelRadiusY; y < height - kernelRadiusY; y++) {
                double sum = 0;

                for (int i = -kernelRadiusX; i <= kernelRadiusX; i++) {
                    for (int j = -kernelRadiusY; j <= kernelRadiusY; j++) {
                        int rgb = inputImage.getPixelReader().getArgb(x + i, y + j);
                        int gray = getGrayscale(rgb);
                        sum += gaussianKernel[i + kernelRadiusX][j + kernelRadiusY] * gray;
                    }
                }
                int blurredValue = (int) Math.min(255, Math.max(0, sum / kernelSum));
                blurWriter.setArgb(x, y, (255 << 24) | (blurredValue << 16) | (blurredValue << 8) | blurredValue);
            }
        }

        return blurredImage;
    }

    public static void applyEdgeDetection() {
        Image currentImage = getCurrentImage();

        assert currentImage != null;
        if (currentImage.getWidth() == 0 || currentImage.getHeight() == 0) {
            throw new IllegalArgumentException("Image dimensions are zero.");
        }

        WritableImage edgeImage = EdgeDetector.detectEdges(currentImage);

        Platform.runLater(() -> setupViewport(edgeImage, false));
    }

}
