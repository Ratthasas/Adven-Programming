package se223.project1.function;

import javafx.application.Platform;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;

import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static se223.project1.function.Cropping.resetProcess;

public class ShowPopup {
    private static final Set<Alert> activeAlerts = new HashSet<>();

    public static void showError(String message) {
        try {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(message);
            Button closeAllButton = new Button("Close All Alerts");
            closeAllButton.setOnAction(event -> closeAllAlerts());
            HBox Box = new HBox(10, closeAllButton);
            DialogPane dialogPane = alert.getDialogPane();
            dialogPane.setExpandableContent(Box);

            alert.setOnHidden(event -> {
                synchronized (activeAlerts) {
                    activeAlerts.remove(alert);
                }
            });

            synchronized (activeAlerts) {
                activeAlerts.add(alert);
            }

            alert.showAndWait();
        } catch (IllegalStateException | NullPointerException | ConcurrentModificationException e) {
            handleExceptions(e);
        }
    }

    public static void closeAllAlerts() {
        try {
            Set<Alert> alertsToClose;
            synchronized (activeAlerts) {
                alertsToClose = new HashSet<>(activeAlerts);
            }
            for (Alert alert : alertsToClose) {
                Platform.runLater(alert::close);
            }
            synchronized (activeAlerts) {
                activeAlerts.clear();
            }
        } catch (IllegalStateException | NullPointerException | ConcurrentModificationException e) {
            handleExceptions(e);
        }
    }

    public static void showResetConfirmationDialog() {
        try {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Stop Cropping Process");
            alert.setHeaderText(null);
            alert.setContentText("You are about to stop the cropping process");

            ButtonType Continue = new ButtonType("Continue");
            ButtonType Cancel = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
            alert.getButtonTypes().setAll(Continue, Cancel);

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == Continue) {
                resetProcess();
            }
        } catch (IllegalStateException | NullPointerException | ConcurrentModificationException e) {
            handleExceptions(e);
        }
    }

    private static void handleExceptions(Exception e) {
        showError("An unexpected error occurred: " + e.getClass().getSimpleName());
    }
}