package se223.project1.function;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.TilePane;
import se223.project1.utils.CheckFIleType;

import static se223.project1.model.GalleryManager.displayImage;

import java.io.*;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.concurrent.ExecutorService;

import static se223.project1.function.ShowPopup.showError;

public class DragDropHandler {

    public static void setupDragAndDrop(Node onNode, TilePane imageTile, ExecutorService executorService) {
        onNode.setOnDragOver(event -> {
            if (event.getDragboard().hasFiles()) {
                event.acceptTransferModes(TransferMode.ANY);
            }
            event.consume();
        });

        onNode.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            boolean success = false;

            if (db.hasFiles()) {
                success = true;
                List<File> files = db.getFiles();

                for (File file : files) {
                    try {
                        processFile(executorService, file, imageTile);
                    } catch (DragDropException e) {
                        Platform.runLater(() -> showError("Error: " + e.getMessage()));
                    }
                }
            }
            event.setDropCompleted(success);
            event.consume();
        });
    }

    private static void processFile(ExecutorService executorService, File file, TilePane imageTile) {
        try {
            if (CheckFIleType.isSupportedImage(file)) {
                executorService.submit(() -> displayImage(executorService, file, imageTile));
            } else if (file.getName().endsWith(".zip")) {
                executorService.submit(() -> {
                    try {
                        extractAndDisplayZip(executorService, file, imageTile);
                    } catch (IOException e) {
                        throw new DragDropException("Error extracting ZIP file: " + file.getName(), e);
                    }
                });
            } else {
                throw new DragDropException("Unsupported file type: " + file.getName());
            }
        } catch (RuntimeException ex) {
            throw new DragDropException("Error processing file: " + file.getName(), ex);
        }
    }

    public static void extractAndDisplayZip(ExecutorService executorService, File zipFile, TilePane imageTile) throws IOException {

        try (ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry entry;
            while ((entry = zipInputStream.getNextEntry()) != null) {
                if (CheckFIleType.isSupportedImage(new File(entry.getName()))) {
                    String fileName = new File(entry.getName()).getName();
                    File extractedFile = new File(System.getProperty("java.io.tmpdir"), fileName);
                    extractedFile.deleteOnExit();

                    try (FileOutputStream fos = new FileOutputStream(extractedFile)) {
                        byte[] buffer = new byte[1024];
                        int len;
                        while ((len = zipInputStream.read(buffer)) > 0) {
                            fos.write(buffer, 0, len);
                        }
                    }

                    Platform.runLater(() -> displayImage(executorService, extractedFile, imageTile));
                } else {
                    throw new DragDropException("Unsupported file type in ZIP: " + entry.getName());
                }
            }
        } catch (IOException e) {
            throw new DragDropException("Failed to process ZIP file: " + zipFile.getName(), e);
        }
    }

    public static class DragDropException extends RuntimeException {
        public DragDropException(String message) {
            super(message);
        }

        public DragDropException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
