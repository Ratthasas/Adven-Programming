package se223.project1.function;

import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.geometry.Insets;
import javafx.geometry.Rectangle2D;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import se223.project1.model.GalleryManager;

import java.util.HashMap;

import static se223.project1.function.ShowPopup.showError;
import static se223.project1.function.ShowPopup.showResetConfirmationDialog;
import static se223.project1.model.GalleryManager.lastSelectedPane;
import static se223.project1.model.GalleryManager.selectedPanes;
import static se223.project1.model.ViewportManager.cropBox;
import static se223.project1.model.ViewportManager.viewport;

public class Cropping {
    public static BooleanProperty processing = new SimpleBooleanProperty(false);
    public static HashMap<Pane, WritableImage> croppedImages = new HashMap<>();
    public static boolean cropMode = true;

    public static WritableImage takeSnapshot() {
        try {
            return tryTakeSnapshot();
        } catch (NullPointerException e) {
            showError("An element was not found. Please make sure all UI components are properly initialized.");
            throw new CroppingException("Error due to null element.", e);
        } catch (IllegalStateException e) {
            showError("Illegal state during cropping. Ensure the application is in the correct mode.");
            throw new CroppingException("Illegal state encountered while taking snapshot.", e);
        } catch (IllegalArgumentException e) {
            showError("Invalid arguments provided. Check the crop box size and position.");
            throw new CroppingException("Invalid arguments for snapshot.", e);
        } catch (RuntimeException e) {
            showError(e.getMessage() + " Make sure the crop box is not too small.");
            throw new CroppingException("Error occurred while taking snapshot.", e);
        }
    }

    private static WritableImage tryTakeSnapshot() {
        try {
            ScrollPane scrollPane = (ScrollPane) viewport.getChildren().getFirst();
            StackPane stackPane = (StackPane) scrollPane.getContent();
            ImageView imageView = (ImageView) stackPane.getChildren().getFirst();

            double viewportWidth = scrollPane.getViewportBounds().getWidth();
            double viewportHeight = scrollPane.getViewportBounds().getHeight();
            WritableImage snapshot = new WritableImage((int) cropBox.getWidth(), (int) cropBox.getHeight());
            SnapshotParameters parameters = new SnapshotParameters();

            Platform.runLater(() -> {
                parameters.setViewport(new Rectangle2D(
                        (viewportWidth / 2 - cropBox.getWidth() / 2) + 1,
                        (viewportHeight / 2 - cropBox.getHeight() / 2) + 1,
                        cropBox.getWidth(), cropBox.getHeight()
                ));
                imageView.snapshot(parameters, snapshot);
            });

            return snapshot;
        } catch (NullPointerException e) {
            throw new NullPointerException("UI element is null.");
        } catch (IllegalStateException e) {
            throw new IllegalStateException("Invalid state during snapshot processing.");
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid parameters for cropping.");
        } catch (RuntimeException e) {
            throw new RuntimeException("General error occurred in tryTakeSnapshot.", e);
        }
    }

    public static void resetProcess() {
        processing.set(false);
        if (lastSelectedPane != null) {
            lastSelectedPane.setBackground(new Background(new BackgroundFill(Color.ALICEBLUE, CornerRadii.EMPTY, Insets.EMPTY)));
        }
        selectedPanes.forEach(GalleryManager::deselectImage);
        croppedImages.clear();
    }

    public static void createResetProcessContextMenu(ContextMenu contextMenu) {
        MenuItem resetProcess = new MenuItem("Stop Process");
        resetProcess.setOnAction(e -> showResetConfirmationDialog());
        processing.addListener((observable, oldValue, newValue) -> {
            if (newValue) {
                if (!contextMenu.getItems().contains(resetProcess)) {
                    contextMenu.getItems().add(resetProcess);
                }
            } else {
                contextMenu.getItems().remove(resetProcess);
            }
        });

        if (processing.get()) {
            contextMenu.getItems().add(resetProcess);
        }
    }

    public static class CroppingException extends RuntimeException {
        public CroppingException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
