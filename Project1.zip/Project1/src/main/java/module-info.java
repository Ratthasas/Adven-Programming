module se223.project1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.swing;

    opens se223.project1 to javafx.fxml;
    opens se223.project1.controller to javafx.fxml;
    exports se223.project1;
    exports se223.project1.controller;
}